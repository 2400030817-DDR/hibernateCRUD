package com.klef.fsad.exam;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.Date;

public class ClientDemo {

    // Build SessionFactory from hibernate.cfg.xml
    private static SessionFactory buildSessionFactory() {
        return new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    }

    // ─────────────────────────────────────────────
    // I. INSERT a new CustomerAccount record
    // ─────────────────────────────────────────────
    public static void insertCustomer(SessionFactory sf) {
        Session session = sf.openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();

            CustomerAccount ca = new CustomerAccount(
                "Alice Johnson",
                "Premium savings account holder",
                new Date(),
                "ACTIVE",
                "alice@example.com",
                "9876543210",
                15000.00
            );

            session.save(ca);
            tx.commit();
            System.out.println("✔ Record Inserted Successfully: " + ca);

        } catch (Exception e) {
            if (tx != null) tx.rollback();
            System.out.println("✘ Insert Failed: " + e.getMessage());
        } finally {
            session.close();
        }
    }

    // ─────────────────────────────────────────────
    // II. UPDATE Name and Status based on ID
    // ─────────────────────────────────────────────
    public static void updateCustomer(SessionFactory sf, int id,
                                      String newName, String newStatus) {
        Session session = sf.openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();

            CustomerAccount ca = session.get(CustomerAccount.class, id);

            if (ca != null) {
                ca.setName(newName);
                ca.setStatus(newStatus);
                session.update(ca);
                tx.commit();
                System.out.println("✔ Record Updated Successfully: " + ca);
            } else {
                System.out.println("✘ No record found with ID: " + id);
            }

        } catch (Exception e) {
            if (tx != null) tx.rollback();
            System.out.println("✘ Update Failed: " + e.getMessage());
        } finally {
            session.close();
        }
    }

    // ─────────────────────────────────────────────
    // MAIN
    // ─────────────────────────────────────────────
    public static void main(String[] args) {
        SessionFactory sf = buildSessionFactory();

        System.out.println("\n========== OPERATION I: INSERT ==========");
        insertCustomer(sf);

        System.out.println("\n========== OPERATION II: UPDATE ==========");
        // Update the record with ID = 1 (auto-generated after insert)
        updateCustomer(sf, 1, "Alice Smith", "INACTIVE");

        sf.close();
        System.out.println("\n========== DONE ==========");
    }
}
