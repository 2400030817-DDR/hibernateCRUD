package com.klef.fsad.exam;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "customer_account")
public class CustomerAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Column(name = "description", length = 255)
    private String description;

    @Column(name = "created_date")
    @Temporal(TemporalType.DATE)
    private Date date;

    @Column(name = "status", length = 50)
    private String status;

    @Column(name = "email", length = 100)
    private String email;

    @Column(name = "phone", length = 15)
    private String phone;

    @Column(name = "balance")
    private double balance;

    // Default Constructor
    public CustomerAccount() {}

    // Parameterized Constructor
    public CustomerAccount(String name, String description, Date date,
                           String status, String email, String phone, double balance) {
        this.name = name;
        this.description = description;
        this.date = date;
        this.status = status;
        this.email = email;
        this.phone = phone;
        this.balance = balance;
    }

    // Getters and Setters
    public int getId()                      { return id; }
    public void setId(int id)               { this.id = id; }

    public String getName()                 { return name; }
    public void setName(String name)        { this.name = name; }

    public String getDescription()          { return description; }
    public void setDescription(String d)    { this.description = d; }

    public Date getDate()                   { return date; }
    public void setDate(Date date)          { this.date = date; }

    public String getStatus()               { return status; }
    public void setStatus(String status)    { this.status = status; }

    public String getEmail()                { return email; }
    public void setEmail(String email)      { this.email = email; }

    public String getPhone()                { return phone; }
    public void setPhone(String phone)      { this.phone = phone; }

    public double getBalance()              { return balance; }
    public void setBalance(double balance)  { this.balance = balance; }

    @Override
    public String toString() {
        return "CustomerAccount{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", date=" + date +
                ", status='" + status + '\'' +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                ", balance=" + balance +
                '}';
    }
}
