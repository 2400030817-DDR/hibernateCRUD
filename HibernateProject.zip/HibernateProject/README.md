# Maven Hibernate Project – CustomerAccount

## Prerequisites
- Java 11+
- Maven 3.6+
- MySQL Server running locally

---

## Setup Steps

### 1. Create the MySQL Database
Open MySQL and run:
```sql
CREATE DATABASE IF NOT EXISTS fsadexam;
```
> Hibernate will auto-create the `customer_account` table on first run.

---

### 2. Update DB Credentials (if needed)
Edit `src/main/resources/hibernate.cfg.xml`:
```xml
<property name="hibernate.connection.username">root</property>
<property name="hibernate.connection.password">root</property>
```
Change `root` / `root` to your MySQL username and password.

---

### 3. Open in VS Code
- Install the **Extension Pack for Java** in VS Code.
- Open the `HibernateProject` folder.

---

### 4. Build the Project
In the VS Code terminal:
```bash
mvn clean compile
```

---

### 5. Run the Project
```bash
mvn exec:java -Dexec.mainClass="com.klef.fsad.exam.ClientDemo"
```
Or run directly via the VS Code Java runner (right-click `ClientDemo.java` → Run Java).

---

## Expected Output
```
========== OPERATION I: INSERT ==========
✔ Record Inserted Successfully: CustomerAccount{id=1, name='Alice Johnson', ...}

========== OPERATION II: UPDATE ==========
✔ Record Updated Successfully: CustomerAccount{id=1, name='Alice Smith', status='INACTIVE', ...}

========== DONE ==========
```

---

## Project Structure
```
HibernateProject/
├── pom.xml
├── README.md
└── src/
    └── main/
        ├── java/
        │   └── com/klef/fsad/exam/
        │       ├── CustomerAccount.java   ← Entity class
        │       └── ClientDemo.java        ← Main class
        └── resources/
            └── hibernate.cfg.xml         ← DB config
```
